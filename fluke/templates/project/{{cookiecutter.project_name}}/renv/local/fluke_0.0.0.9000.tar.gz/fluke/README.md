# Fluke: an opinionated R data science framework

## Motivation

Think of Ruby-on-Rails, but for making data scientists' lives easier in R!

## Developer setup
To recreate the environment used for package dev, run:

```sh
make dev-setup
```
This will install the necessary R and Python packages.

